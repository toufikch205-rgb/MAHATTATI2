const $=id=>document.getElementById(id);let lang='ar',mode='car',selecting='pickup',userMarker=null,pickupMarker=null,destMarker=null,accuracyCircle=null,userLatLng=null;
const words={ar:{mapLabel:'من أين',mapDefault:'موقعك الحالي',car:'رحلة بسعر عادل',intercity:'بين الولايات',destination:'ما وجهتك وكم التكلفة؟',pickup:'نقطة الانطلاق',pickupPh:'موقعي الحالي',dest:'الوجهة',destPh:'إلى أين تريد الذهاب؟',continue:'متابعة الطلب　↗',mapNote:'موقعك على الخريطة',locating:'جارٍ تحديد موقعك…',located:'تم تحديد موقعك',noLocation:'تعذر تحديد الموقع — تحقق من الإذن',pickPrompt:'اضغط على الخريطة لتحديد نقطة الانطلاق',destPrompt:'اضغط على الخريطة لتحديد الوجهة',needDest:'أدخل الوجهة أو اخترها من الخريطة أولًا.',picked:'تم تحديد نقطة الانطلاق على الخريطة.',destSet:'تم تحديد الوجهة على الخريطة.',demo:'هذه واجهة تجريبية؛ ربط السائقين والطلبات يأتي في المرحلة التالية.',menuDemo:'القائمة والإشعارات ستُضاف في المرحلة التالية.',promoTitle:'سائقونا وسياراتنا موثوقون',promoText:'جميع السائقين والسيارات يتم التحقق منهم',promoMore:'اعرف أكثر',language:'FR'},fr:{mapLabel:'Départ',mapDefault:'Votre position actuelle',car:'Course à prix juste',intercity:'Inter-wilayas',destination:'Où allez-vous et à quel prix ?',pickup:'Point de départ',pickupPh:'Ma position actuelle',dest:'Destination',destPh:'Où souhaitez-vous aller ?',continue:'Continuer　↗',mapNote:'Votre position sur la carte',locating:'Localisation en cours…',located:'Position détectée',noLocation:'Position indisponible — vérifiez l’autorisation',pickPrompt:'Touchez la carte pour choisir le départ',destPrompt:'Touchez la carte pour choisir la destination',needDest:'Saisissez une destination ou choisissez-la sur la carte.',picked:'Point de départ sélectionné.',destSet:'Destination sélectionnée.',demo:'Version de démonstration : la connexion aux chauffeurs viendra ensuite.',menuDemo:'Le menu et les notifications seront ajoutés ensuite.',promoTitle:'Des chauffeurs et véhicules vérifiés',promoText:'Les chauffeurs et les véhicules sont vérifiés',promoMore:'En savoir plus',language:'ع'}};
function say(k){return words[lang][k]||k}function toast(t){$('toast').textContent=t;$('toast').classList.add('show');clearTimeout(window.tt);window.tt=setTimeout(()=>$('toast').classList.remove('show'),2800)}
function applyLang(){const w=words[lang];document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';$('mapLabel').textContent=w.mapLabel;$('carTitle').textContent=w.car;$('intercityTitle').textContent=w.intercity;$('destinationPrompt').textContent=w.destination;$('pickupLabel').textContent=w.pickup;$('destLabel').textContent=w.dest;$('pickupInput').placeholder=w.pickupPh;$('destInput').placeholder=w.destPh;$('continueBtn').textContent=w.continue;$('mapNote').textContent=w.mapNote;$('promoTitle').textContent=w.promoTitle;$('promoText').textContent=w.promoText;$('promoMore').textContent=w.promoMore;if(!userLatLng)$('mapAddress').textContent=w.mapDefault;}
const map=L.map('map',{zoomControl:false,scrollWheelZoom:true}).setView([35.6971,-0.6308],15);L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19,attribution:'© OpenStreetMap'}).addTo(map);
function divIcon(html,size=[40,40],anchor=[20,20]){return L.divIcon({className:'',html,iconSize:size,iconAnchor:anchor})}
function setUser(latlng,acc=80){userLatLng=latlng;const icon=divIcon('<div class="custom-user"><span>🙋🏻</span></div>',[46,46],[23,23]);if(!userMarker)userMarker=L.marker(latlng,{icon,zIndexOffset:900}).addTo(map);else userMarker.setLatLng(latlng).setIcon(icon);if(accuracyCircle)map.removeLayer(accuracyCircle);accuracyCircle=L.circle(latlng,{radius:Math.max(acc,25),color:'#7dd3fc',weight:1,opacity:.8,fillColor:'#7dd3fc',fillOpacity:.18}).addTo(map);$('mapAddress').textContent=say('mapDefault');$('locationStatus')?.textContent; if(!$('pickupInput').value)$('pickupInput').value=say('mapDefault');}
function locate(){
  if (!navigator.geolocation) {
    $('mapAddress').textContent = say('noLocation');
    toast(say('noLocation'));
    return;
  }

  $('mapAddress').textContent = say('locating');

  navigator.geolocation.getCurrentPosition(
    pos => {
      const ll = L.latLng(pos.coords.latitude, pos.coords.longitude);
      setUser(ll, pos.coords.accuracy || 80);
      map.setView(ll, 17, { animate: true });
      $('mapAddress').textContent =
        lang === 'ar' ? 'تم تحديد موقعك' : 'Position détectée';
    },
    err => {
      $('mapAddress').textContent = say('noLocation');
      const denied = err && err.code === 1;
      toast(denied
        ? (lang === 'ar'
            ? 'يرجى السماح بالوصول إلى الموقع من إعدادات المتصفح'
            : 'Autorisez la localisation dans les paramètres du navigateur')
        : say('noLocation'));
    },
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
  );
}
function setSelectMode(m){selecting=m;$('mapNote').textContent=say(m==='pickup'?'pickPrompt':'destPrompt');toast(say(m==='pickup'?'pickPrompt':'destPrompt'));}
map.on('click',e=>{const ll=e.latlng;const isPickup=selecting==='pickup';const icon=divIcon(`<div class="custom-pin ${isPickup?'green':'red'}"></div>`,[28,28],[14,25]);if(isPickup){if(pickupMarker)map.removeLayer(pickupMarker);pickupMarker=L.marker(ll,{icon}).addTo(map);$('pickupInput').value=`${ll.lat.toFixed(5)}, ${ll.lng.toFixed(5)}`;toast(say('picked'));}else{if(destMarker)map.removeLayer(destMarker);destMarker=L.marker(ll,{icon}).addTo(map);$('destInput').value=`${ll.lat.toFixed(5)}, ${ll.lng.toFixed(5)}`;toast(say('destSet'));}selecting=isPickup?'dest':'pickup';$('mapNote').textContent=say(selecting==='pickup'?'pickPrompt':'destPrompt');});
$('locateBtn').onclick=locate;$('zoomIn').onclick=()=>map.zoomIn();$('pickOnMap').onclick=()=>setSelectMode('pickup');$('destOnMap').onclick=()=>setSelectMode('dest');$('destinationFocus').onclick=()=>{$('destInput').focus();document.querySelector('.route-fields').classList.add('open');};$('carService').onclick=()=>{mode='car';$('carService').classList.add('active');$('intercityService').classList.remove('active');};$('intercityService').onclick=()=>{mode='intercity';$('intercityService').classList.add('active');$('carService').classList.remove('active');toast(lang==='ar'?'تم اختيار رحلة بين الولايات':'Trajet inter-wilayas sélectionné')};$('continueBtn').onclick=()=>{if(!$('destInput').value.trim()){toast(say('needDest'));$('destInput').focus();return}toast(say('demo'))};$('menuBtn').onclick=()=>toast(say('menuDemo'));$('pickupBadge').onclick=()=>setSelectMode('pickup');$('promoMore').onclick=()=>toast(lang==='ar'?'سيتم إضافة تفاصيل التحقق من السائقين لاحقًا':'Les détails de vérification seront ajoutés ensuite');
applyLang();setTimeout(()=>map.invalidateSize(),300);map.whenReady(()=>setTimeout(locate,350));window.addEventListener('resize',()=>map.invalidateSize());
